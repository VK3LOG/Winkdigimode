# WINK v0.2 — waveform bake-off results & adaptive-profile validation

## 1. Root cause of the v0.1 failure

v0.1 (8-FSK, 15 baud, 2.5 Hz tone spacing) collapsed between -5 and -10 dB
in the original benchmark. The cause is a waveform-design bug, not a
receiver or FEC weakness: **for non-coherent M-FSK, adjacent tone
detectors need spacing >= the symbol (baud) rate** to be orthogonal. At
15 baud (66.7 ms/symbol), the minimum safe spacing is 15 Hz. v0.1 used
2.5 Hz — six times too tight — so the tone-energy detectors constantly
stole energy from their neighbours, and no amount of stronger FEC could
fix that at the physical layer.

## 2. The v0.1 bake-off's channel model was also invalid

`waveform_bakeoff/wink_bakeoff.py` scored every candidate at 0.0% BER
down to -18 dB regardless of M/baud/spacing. That's because its noise
model held `sigma` fixed while the correct-tone amplitude scaled with
`sqrt(sps)` (samples per symbol) — so any candidate with more samples per
symbol got a free, un-modelled processing-gain bonus baked into the
"SNR" axis. It could not have discriminated between the four candidates
and shouldn't be trusted as a comparison (this was already flagged in
`WINK_BAKEOFF.md`).

## 3. What v0.2 does differently (`v02/`)

`wink_modem2.py` is a real sample-domain simulation, common to every
candidate:
- continuous-phase audio synthesis at 12 kHz
- AWGN added once, at the waveform-sample level (one shared SNR
  definition, so no candidate gets accidental extra processing gain)
- non-coherent tone-energy (matched-filter) detection, vectorised
- an **unknown carrier-frequency offset** (+-3 Hz, modelling TX/RX
  oscillator mismatch) and an **unknown symbol start time**, both
  recovered by a coarse search against the sync sequence before data
  demod — the "add CFO + timing error" step called for next in the
  original project summary
- the same K=7 rate-1/2 convolutional code, interleaver, and CRC-gated
  packet framing as v0.1 (`wink_core.py`), unchanged

This measures *whole-packet* success through the real chain, not a raw
per-symbol BER on an idealised channel.

## 4. Results

`run_bakeoff2.py` (40 trials/point, -2 to -20 dB) confirms the diagnosis
cleanly:

| candidate | spacing/baud | outcome |
|---|---|---|
| 8-FSK/15Bd/2.5Hz (v0.1 original) | 0.17x | collapses -8→-14 dB, 0% by -14 dB |
| 4-FSK/10Bd/5Hz | 0.5x | starts degrading at -18 dB, 27.5% at -20 dB |
| 8-FSK/7.5Bd/5Hz | 0.67x | 95% at -20 dB, otherwise solid |
| 4-FSK/7.5Bd/6.67Hz | 0.89x | 100% through -20 dB |
| 8-FSK/5Bd/7.5Hz | 1.5x | 100% through -20 dB |

The pattern is exactly what the orthogonality condition predicts:
spacing/baud >= 1 gives clean performance; below that, degradation
appears earlier and more severely the further below 1x you go.

Extending the SNR sweep further down (`bakeoff2_extended.csv`, 60
trials/point) to find real 50%-success thresholds for the two winners:

- **4-FSK/7.5Bd/6.67Hz: ~-22 dB** (100%@-21, 62%@-22, 7%@-23)
- **8-FSK/5Bd/7.5Hz: ~-23.5 dB** (93%@-22, 67%@-23, 8%@-24)

Both candidates carry the same coded throughput (7.5 bit/s after rate-1/2
FEC), but 8-FSK/5Bd/7.5Hz is ~1.5 dB more sensitive at the cost of ~2.25x
more occupied bandwidth (60 Hz vs 26.7 Hz) — the standard MFSK
bandwidth/sensitivity trade.

## 5. Chosen v0.2 profiles (`wink_profiles.py`)

Three profiles, all 8-FSK with spacing == baud (orthogonality-safe by
construction), spanning the WINK-S/N/F design in the project summary:

| profile | baud | spacing | occupied | coded bps | measured 50% threshold |
|---|---|---|---|---|---|
| WINK-S | 5 | 7.5 Hz | 60 Hz | 7.5 | **-23.5 dB** |
| WINK-N | 15 | 15 Hz | 120 Hz | 22.5 | **-18.5 dB** |
| WINK-F | 30 | 30 Hz | 240 Hz | 45 | **-15.5 dB** |

Each ~3x speed step costs roughly 5 dB of sensitivity — consistent with
expected FSK behaviour, and a sane basis for the adaptive-profile
hysteresis logic.

## 6. Adaptive-profile logic, validated end to end

`wink_profiles.recommend_profile()` implements the receiver-driven
adaptation from the project summary: step down immediately if the
current profile has lost its margin, step up one notch at a time only
once the faster profile has margin too (prevents mode-flapping).

`demo_adaptive_qso.py` runs a full simulated QSO — TEXT packets, then a
LINK_REPORT packet carrying measured SNR and the recommended profile —
through the real channel model as SNR rises and falls over 12 exchanges.
Result: correctly stayed on WINK-S while too weak to copy at all
(-25/-24 dB), stepped up to WINK-N once conditions supported it, stepped
back down to WINK-S as the band faded, with no flapping. This is the
first time packet layer + physical layer + adaptive-profile logic have
been exercised together as one system.

## 7. What's still not done (v0.2 does NOT claim these)

- **No real audio I/O.** Everything above is a numerical simulation;
  nothing has touched a sound card or a radio yet.
- **No multipath/fading model.** AWGN only — HF selective fading and
  multipath will very likely change the picture, especially at the
  wider WINK-N/F bandwidths.
- **No MCU/beacon implementation.** Still a design concept.
- **No mesh/routing implementation.** Still a design concept.
- **LLRs are still hard-decision** (+-5.0), not derived from actual
  tone-energy soft metrics — a real soft-decision Viterbi front end
  using measured energy margins would likely add another 1-2 dB and is
  a reasonable next step before real audio I/O.
- These are simulated, idealised-channel results with no fading or real
  RF impairments — a -23 dB "sensitivity" number here should be read as
  "the waveform + FEC combination is fundamentally sound," not as a
  claimed over-the-air decode threshold.

## 8. Error-correction improvements (this round)

Two changes, tested independently and combined, on WINK-S near its
threshold (`winkS_fec_comparison.csv`, 60 trials/point):

1. **Soft-decision LLRs.** The receiver previously threw away
   confidence information: every bit got a fixed +-5.0 LLR regardless
   of how clean or noisy that symbol actually was. `wink_modem2.
   soft_llrs_from_energies()` now computes a real max-log LLR per bit
   from the actual tone-energy margins, normalised by each symbol's own
   noise-floor estimate (so a symbol that landed in a noisy instant is
   automatically down-weighted relative to a clean one — the whole
   point of soft-decision decoding).
2. **Stronger convolutional code.** Added K=9 (Voyager-standard,
   dfree=12, generators 753/561 octal) alongside the existing K=7
   (dfree=10). Both are now selectable per-packet via
   `simulate_packet(..., fec=..., llr_mode=...)`.

| FEC | LLR mode | WINK-S 50%-threshold |
|---|---|---|
| K7 | hard (v0.1/v0.2-original) | -23.2 dB |
| K7 | soft | -24.0 dB |
| K9 | hard | -23.6 dB |
| K9 | soft | **-24.3 dB** |

Soft decoding alone accounts for most of the gain (~0.9 dB); the
stronger code adds a further ~0.3 dB on top of that. Re-validating
WINK-N and WINK-F with the winning K9+soft combo
(`winkNF_K9soft.csv`) shows the same ~1-1.2 dB improvement holds across
all three profiles:

| profile | old threshold (K7/hard) | new threshold (K9/soft) |
|---|---|---|
| WINK-S | -23.2 dB | **-24.3 dB** |
| WINK-N | -18.5 dB | **-19.5 dB** |
| WINK-F | -15.5 dB | **-16.7 dB** |

K9+soft is now the default (`wink_profiles.DEFAULT_FEC`/
`DEFAULT_LLR_MODE`); the adaptive QSO demo re-run with it decodes text
at -24 dB where the old receiver failed, and now exercises all three
profile transitions (S→N→F→N→S) as the simulated band opens and closes.

A 1-1.2 dB gain is a real, measured improvement, not a dramatic one —
that's expected: soft-decision decoding over hard-decision is a
well-known, bounded gain (textbook range is roughly 2 dB for AWGN
channels; less here since the max-log LLR approximation and per-symbol
noise-floor estimate aren't a fully calibrated likelihood). Larger
further gains would need a structurally different approach (e.g. a
longer/lower-rate code, real diversity combining, or accepting more
latency for repeat transmissions) rather than tuning this same
convolutional/Viterbi scheme further.

## 10. Diversity combining (optional, costs time-on-air)

`simulate_packet_diversity()` sends the same packet over 2 or 3
independent channel draws (independent CFO/timing/noise, as if
retransmitted a few seconds apart) and soft-combines the LLRs before one
Viterbi decode. Measured on WINK-S (K9+soft), 50 trials/point:

| repeats | time-on-air | 50%-threshold | gain over 1x |
|---|---|---|---|
| 1x (baseline) | 1x | -24.2 dB | -- |
| 2x | 2x | -25.6 dB | +1.3 dB |
| 3x | 3x | -26.5 dB | +2.3 dB |

This is real and reproduces the expected diminishing-returns curve
(ideal coherent combining would give 3.0 dB / 4.8 dB for 2x/3x; the
measured gain is smaller because this is non-coherent M-FSK combining
with an independent sync search per repeat, not perfect coherent
integration). It's a genuine tool for a beacon or a "please repeat"
retry, not a free upgrade — 3x the sensitivity gain costs 3x the
channel time, which is a real trade-off for a shared HF band, not a
strictly-better setting. It is **not** wired into the default profile
or the adaptive-QSO demo; `n_repeats` stays operator/protocol choice.

## 11. Where returns diminish from here

Stacking what's been measured so far: v0.1 (broken, collapsed ~-10 dB)
→ v0.2 waveform fix (-23.2 dB) → soft decoding + K9 (-24.3 dB) → 3x
diversity (-26.5 dB). That's the real, honestly-measured trajectory —
about 16 dB recovered from the original bug, plus a further ~2.3 dB from
tuning on top of an already-fixed design. Every remaining lever left
(longer codes, more repeats, tighter sync search) buys well under 1 dB
per unit of added complexity or time-on-air from here; there is no
"perfect" left to extract from this architecture. The next real jump in
capability, if wanted, comes from modelling what's still entirely
unmodelled — multipath/fading — which will very likely *cost* some of
this margin back once it's honestly accounted for, not add to it. That
and real audio I/O remain the two steps that would change what these
numbers actually mean, rather than just moving them a fraction of a dB.

## 12. Suggested next step

Per the project's own priority order: (4) multipath/fading model, then
(5) real audio I/O loopback, then (6) calibrated comparison against a
known mode (e.g. FT8) under the same conditions.
