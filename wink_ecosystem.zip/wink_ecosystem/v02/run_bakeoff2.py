#!/usr/bin/env python3
"""WINK v0.2 waveform bake-off — realistic packet-success benchmark.

Differences from the v0.1 bake-off (waveform_bakeoff/wink_bakeoff.py):
- real sample-domain AWGN (one SNR definition shared fairly across
  candidates, instead of accidentally baking in extra processing gain
  for whichever candidate has more samples per symbol)
- unknown per-packet carrier frequency offset, recovered by search
- unknown per-packet start time, recovered by search
- measures whole-packet success through the real FEC/interleaver/CRC
  chain, not just a raw symbol/bit error rate on an idealised channel
"""
import csv, sys, time
import numpy as np
from wink_modem2 import CANDIDATES, simulate_packet
from wink_core import Packet, callsign_id

SNRS = [-2, -4, -6, -8, -10, -12, -14, -16, -18, -20]
TRIALS = 40
PAYLOAD = b"hello from WINK"


def run():
    pkt = Packet(1, callsign_id("VK3TEST"), callsign_id("VK5TEST"), 1, PAYLOAD)
    rows = []
    t_start = time.time()
    for c in CANDIDATES:
        for snr in SNRS:
            good = 0
            for t in range(TRIALS):
                rng = np.random.default_rng(hash((c.name, snr, t)) & 0xFFFFFFFF)
                front_pad = int(rng.integers(0, c.sps))
                true_cfo = float(rng.uniform(-3, 3))
                try:
                    rx = simulate_packet(c, pkt, snr, rng, true_cfo, front_pad)
                except Exception:
                    rx = None
                good += int(rx is not None and rx.payload == pkt.payload)
            rows.append([c.name, snr, good, TRIALS, good / TRIALS,
                         c.coded_bps, c.occupied_hz])
            print(f"{c.name:32} {snr:5.1f} dB  {good:3d}/{TRIALS}  "
                  f"({100*good/TRIALS:5.1f}%)  elapsed={time.time()-t_start:5.0f}s",
                  file=sys.stderr)

    with open("bakeoff2_results.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["candidate", "snr_db", "successful", "trials",
                    "success_rate", "coded_bps", "occupied_hz"])
        w.writerows(rows)


if __name__ == "__main__":
    run()
