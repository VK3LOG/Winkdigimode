#!/usr/bin/env python3
"""WINK Monitor -- GTK4/Libadwaita desktop app for the WINK-Beacon /
WINKMESH ecosystem.

STATUS: UI skeleton, running on simulated data. There is no serial
protocol defined yet between this app and the ESP32 firmware
(firmware/), so SpotSource below generates plausible mock spots instead
of reading a real port. Swap SpotSource.poll() for a real pyserial read
once the firmware actually emits status lines -- that's the one seam
this was built around.

Three views:
  - Spots: a WSPRnet-style log of received/transmitted beacon reports
  - TX Control: current mode (WSPR/WINK-Beacon), profile (S/N/F) for
    WINK-N/F QSO traffic, and manual profile override
  - Settings: callsign/locator/power, mirrors firmware/src/config.h
"""
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib, Gio

import random
from datetime import datetime, timezone


class SpotSource:
    """Stand-in for a real data feed. Replace poll() with a pyserial
    read once the firmware defines a status-line protocol (e.g. one
    JSON line per completed TX/decode)."""

    CALLSIGNS = ["VK3LOG", "VK2ABC", "ZL1XYZ", "JA1DEF", "W1AW"]
    LOCATORS = ["QF22", "QF56", "RF73", "PM95", "FN31"]
    MODES = ["WSPR", "WINK-Beacon"]

    def poll(self):
        if random.random() < 0.4:
            return None
        return {
            "time": datetime.now(timezone.utc).strftime("%H:%M:%S"),
            "callsign": random.choice(self.CALLSIGNS),
            "locator": random.choice(self.LOCATORS),
            "mode": random.choice(self.MODES),
            "snr_db": round(random.uniform(-30, -5), 1),
            "power_dbm": random.choice([23, 27, 30, 37]),
        }


class SpotsPage(Gtk.Box):
    def __init__(self, source: SpotSource):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6,
                          margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
        self.source = source

        self.store = Gio.ListStore()
        columns = [
            ("Time", "time"), ("Callsign", "callsign"), ("Locator", "locator"),
            ("Mode", "mode"), ("SNR (dB)", "snr_db"), ("Power", "power_dbm"),
        ]

        self.list_box = Gtk.ListBox(css_classes=["boxed-list"])
        scroller = Gtk.ScrolledWindow(vexpand=True)
        scroller.set_child(self.list_box)

        header = Adw.PreferencesGroup(title="Spot log", description="WSPR and WINK-Beacon receptions")
        self.append(header)
        self.append(scroller)

        GLib.timeout_add_seconds(3, self._poll_tick)

    def _poll_tick(self):
        spot = self.source.poll()
        if spot:
            self._add_row(spot)
        return True

    def _add_row(self, spot):
        row = Adw.ActionRow(
            title=f"{spot['callsign']}  {spot['locator']}",
            subtitle=f"{spot['mode']} · {spot['snr_db']} dB · {spot['power_dbm']} dBm · {spot['time']} UTC",
        )
        icon = Gtk.Image.new_from_icon_name(
            "network-cellular-signal-good-symbolic" if spot["snr_db"] > -20
            else "network-cellular-signal-weak-symbolic"
        )
        row.add_prefix(icon)
        self.list_box.prepend(row)
        # keep the log bounded
        while len(list(self.list_box)) > 200:
            child = self.list_box.get_last_child()
            if child:
                self.list_box.remove(child)


class TxControlPage(Gtk.Box):
    PROFILES = ["WINK-S", "WINK-N", "WINK-F"]
    THRESHOLDS = {"WINK-S": -24.3, "WINK-N": -19.5, "WINK-F": -16.7}

    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12,
                          margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)

        self.mode_group = Adw.PreferencesGroup(title="Beacon schedule")
        self.mode_row = Adw.ComboRow(title="Alternate modes", subtitle="Matches firmware's TxMode schedule")
        self.mode_row.set_model(Gtk.StringList.new(["WSPR / WINK-Beacon alternating", "WSPR only", "WINK-Beacon only"]))
        self.mode_group.add(self.mode_row)
        self.append(self.mode_group)

        self.profile_group = Adw.PreferencesGroup(
            title="Adaptive profile (WINK-N/F QSO traffic)",
            description="Auto-follows recommend_profile() from the measured link SNR; override below forces a fixed profile.",
        )
        self.auto_switch = Adw.SwitchRow(title="Auto (adaptive)", active=True)
        self.auto_switch.connect("notify::active", self._on_auto_toggled)
        self.profile_group.add(self.auto_switch)

        self.profile_row = Adw.ComboRow(title="Manual profile", sensitive=False)
        self.profile_row.set_model(Gtk.StringList.new(self.PROFILES))
        self.profile_group.add(self.profile_row)
        self.append(self.profile_group)

        self.status_group = Adw.PreferencesGroup(title="Current link")
        self.snr_row = Adw.ActionRow(title="Measured SNR", subtitle="-19.8 dB (simulated)")
        self.profile_status_row = Adw.ActionRow(title="Active profile", subtitle="WINK-N")
        self.status_group.add(self.snr_row)
        self.status_group.add(self.profile_status_row)
        self.append(self.status_group)

    def _on_auto_toggled(self, switch, _pspec):
        self.profile_row.set_sensitive(not switch.get_active())


class SettingsPage(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12,
                          margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)

        station = Adw.PreferencesGroup(title="Station", description="Mirrors firmware/src/config.h")
        self.callsign_row = Adw.EntryRow(title="Callsign")
        self.callsign_row.set_text("VK3LOG")
        self.locator_row = Adw.EntryRow(title="Locator (4-char)")
        self.locator_row.set_text("QF22")
        self.power_row = Adw.SpinRow.new_with_range(0, 63, 1)
        self.power_row.set_title("Power (dBm)")
        self.power_row.set_value(27)
        station.add(self.callsign_row)
        station.add(self.locator_row)
        station.add(self.power_row)
        self.append(station)

        conn = Adw.PreferencesGroup(title="Firmware connection")
        self.port_row = Adw.EntryRow(title="Serial port")
        self.port_row.set_text("(not connected \u2014 running on simulated data)")
        self.port_row.set_sensitive(False)
        conn.add(self.port_row)
        self.append(conn)


class WinkMonitorWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="WINK Monitor", default_width=720, default_height=560)

        toolbar_view = Adw.ToolbarView()
        header = Adw.HeaderBar()
        toolbar_view.add_top_bar(header)

        view_stack = Adw.ViewStack()
        source = SpotSource()
        view_stack.add_titled_with_icon(SpotsPage(source), "spots", "Spots", "network-workgroup-symbolic")
        view_stack.add_titled_with_icon(TxControlPage(), "tx", "TX Control", "send-to-symbolic")
        view_stack.add_titled_with_icon(SettingsPage(), "settings", "Settings", "preferences-system-symbolic")

        switcher = Adw.ViewSwitcher(stack=view_stack, policy=Adw.ViewSwitcherPolicy.WIDE)
        header.set_title_widget(switcher)

        toolbar_view.set_content(view_stack)
        self.set_content(toolbar_view)


class WinkMonitorApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id="net.vk3log.winkmonitor")

    def do_activate(self):
        win = self.props.active_window or WinkMonitorWindow(self)
        win.present()


if __name__ == "__main__":
    WinkMonitorApp().run()
